/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.hospitalmanagementsystem;
/**
 *
 * @author aishu
 */
public class Billing {
    private String invoiceId;
    private String patientId;
    private double amount;
    private String status;

    public Billing(String invoiceId, String patientId, double amount, String status) {
        this.invoiceId = invoiceId;
        this.patientId = patientId;
        this.amount = amount;
        this.status = status;
    }

    public String getInvoiceId() {
        return invoiceId;
    }

    public String getPatientId() {
        return patientId;
    }

    public double getAmount() {
        return amount;
    }

    public String getStatus() {
        return status;
    }

    @Override
    public String toString() {
        return "Invoice ID: " + invoiceId + ", Patient ID: " + patientId + ", Amount: $" + amount + ", Status: " + status;
    }
}
