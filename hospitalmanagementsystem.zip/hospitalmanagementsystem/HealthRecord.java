/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.hospitalmanagementsystem;

/**
 *
 * @author aishu
 */
public class HealthRecord {
    private String patientId;
    private String medicalHistory;
    private String currentMedication;
    private String allergies;

    public HealthRecord(String patientId, String medicalHistory, String currentMedication, String allergies) {
        this.patientId = patientId;
        this.medicalHistory = medicalHistory;
        this.currentMedication = currentMedication;
        this.allergies = allergies;
    }

    public String getPatientId() {
        return patientId;
    }

    public String getMedicalHistory() {
        return medicalHistory;
    }

    public String getCurrentMedication() {
        return currentMedication;
    }

    public String getAllergies() {
        return allergies;
    }

    @Override
    public String toString() {
        return "Patient ID: " + patientId + ", Medical History: " + medicalHistory;
    }
}

