/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.hospitalmanagementsystem;
/**
 *
 * @author aishu
 */
public class HospitalManagementSystem {

    public static void main(String[] args) {
        System.out.println("Hospital Management System");
    }
}
