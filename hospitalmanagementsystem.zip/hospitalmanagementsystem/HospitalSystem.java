/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.hospitalmanagementsystem;

/**
 *
 * @author aishu
 */
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class HospitalSystem {
    private Map<String, Patient> patients;
    private Map<String, Appointment> appointments;
    private Map<String, HealthRecord> ehrRecords;
    private Map<String, Billing> billings;
    private Inventory inventory;
    private Map<String, Staff> staff;

    public HospitalSystem() {
        patients = new HashMap<>();
        appointments = new HashMap<>();
        ehrRecords = new HashMap<>();
        billings = new HashMap<>();
        inventory = new Inventory();
        staff = new HashMap<>();
    }

    public void registerPatient(String patientId, String name, String dob, String address, String phone) {
        patients.put(patientId, new Patient(patientId, name, dob, address, phone));
        System.out.println("Patient registered successfully.");
    }

    public void scheduleAppointment(String appointmentId, String patientId, String doctorName, Date date, String status) {
        appointments.put(appointmentId, new Appointment(appointmentId, patientId, doctorName, date, status));
        System.out.println("Appointment scheduled successfully.");
    }

    public void addEHR(String patientId, String medicalHistory, String medication, String allergies) {
        ehrRecords.put(patientId, new HealthRecord(patientId, medicalHistory, medication, allergies));
        System.out.println("EHR updated successfully.");
    }

    public void generateBill(String invoiceId, String patientId, double amount, String status) {
        billings.put(invoiceId, new Billing(invoiceId, patientId, amount, status));
        System.out.println("Bill generated successfully.");
    }

    public void addInventory(String item, int quantity) {
        inventory.addSupply(item, quantity);
        System.out.println("Inventory updated.");
    }

    public void useInventory(String item, int quantity) {
        if (inventory.useSupply(item, quantity)) {
            System.out.println("Inventory updated.");
        } else {
            System.out.println("Insufficient stock.");
        }
    }

    public void addStaff(String staffId, String name, String role, String department) {
        staff.put(staffId, new Staff(staffId, name, role, department));
        System.out.println("Staff added successfully.");
    }

    public void printInventory() {
        System.out.println(inventory);
    }

    public void printPatients() {
        for (Patient patient : patients.values()) {
            System.out.println(patient);
        }
    }

    public void printAppointments() {
        for (Appointment appointment : appointments.values()) {
            System.out.println(appointment);
        }
    }

    public void printEHR() {
        for (HealthRecord ehr : ehrRecords.values()) {
            System.out.println(ehr);
        }
    }

    public void printBillings() {
        for (Billing billing : billings.values()) {
            System.out.println(billing);
        }
    }

    public void printStaff() {
        for (Staff staffMember : staff.values()) {
            System.out.println(staffMember);
        }
    }
}
