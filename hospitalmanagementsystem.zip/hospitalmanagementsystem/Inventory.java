/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.hospitalmanagementsystem;
/**
 *
 * @author aishu
 */
import java.util.HashMap;
import java.util.Map;

public class Inventory {
    private Map<String, Integer> supplies;

    public Inventory() {
        supplies = new HashMap<>();
    }

    public void addSupply(String item, int quantity) {
        supplies.put(item, supplies.getOrDefault(item, 0) + quantity);
    }

    public boolean useSupply(String item, int quantity) {
        if (supplies.containsKey(item) && supplies.get(item) >= quantity) {
            supplies.put(item, supplies.get(item) - quantity);
            return true;
        }
        return false;
    }

    @Override
    public String toString() {
        return "Inventory: " + supplies.toString();
    }
}

