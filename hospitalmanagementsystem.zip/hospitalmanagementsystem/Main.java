/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.hospitalmanagementsystem;

/**
 *
 * @author aishu
 */
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        HospitalSystem hms = new HospitalSystem();
        Scanner scanner = new Scanner(System.in);
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

        while (true) {
            System.out.println("Hospital Management System");
            System.out.println("1. Register Patient");
            System.out.println("2. Schedule Appointment");
            System.out.println("3. Add EHR");
            System.out.println("4. Generate Bill");
            System.out.println("5. Manage Inventory");
            System.out.println("6. Add Staff");
            System.out.println("7. Print Reports");
            System.out.println("8. Exit");
            System.out.print("Choose an option: ");

            int option = scanner.nextInt();
            scanner.nextLine();  
            
            switch (option) {
                case 1:
                    System.out.print("Enter patient ID: ");
                    String patientId = scanner.nextLine();
                    System.out.print("Enter patient name: ");
                    String name = scanner.nextLine();
                    System.out.print("Enter date of birth (YYYY-MM-DD): ");
                    String dob = scanner.nextLine();
                    System.out.print("Enter address: ");
                    String address = scanner.nextLine();
                    System.out.print("Enter phone number: ");
                    String phone = scanner.nextLine();
                    hms.registerPatient(patientId, name, dob, address, phone);
                    break;

                case 2:
                    System.out.print("Enter appointment ID: ");
                    String appointmentId = scanner.nextLine();
                    System.out.print("Enter patient ID: ");
                    String patId = scanner.nextLine();
                    System.out.print("Enter doctor name: ");
                    String doctorName = scanner.nextLine();
                    System.out.print("Enter appointment date (YYYY-MM-DD): ");
                    Date date = null;
                    try {
                        date = dateFormat.parse(scanner.nextLine());
                    } catch (ParseException e) {
                        e.printStackTrace();
                    }
                    System.out.print("Enter status: ");
                    String status = scanner.nextLine();
                    hms.scheduleAppointment(appointmentId, patId, doctorName, date, status);
                    break;

                case 3:
                    System.out.print("Enter patient ID: ");
                    String ehrPatientId = scanner.nextLine();
                    System.out.print("Enter medical history: ");
                    String medicalHistory = scanner.nextLine();
                    System.out.print("Enter current medication: ");
                    String medication = scanner.nextLine();
                    System.out.print("Enter allergies: ");
                    String allergies = scanner.nextLine();
                    hms.addEHR(ehrPatientId, medicalHistory, medication, allergies);
                    break;

                case 4:
                    System.out.print("Enter invoice ID: ");
                    String invoiceId = scanner.nextLine();
                    System.out.print("Enter patient ID: ");
                    String billPatientId = scanner.nextLine();
                    System.out.print("Enter amount: ");
                    double amount = scanner.nextDouble();
                    scanner.nextLine();  // Consume newline
                    System.out.print("Enter status: ");
                    String billStatus = scanner.nextLine();
                    hms.generateBill(invoiceId, billPatientId, amount, billStatus);
                    break;

                case 5:
                    System.out.println("1. Add Supply");
                    System.out.println("2. Use Supply");
                    System.out.print("Choose an option: ");
                    int inventoryOption = scanner.nextInt();
                    scanner.nextLine();  // Consume newline
                    if (inventoryOption == 1) {
                        System.out.print("Enter item name: ");
                        String item = scanner.nextLine();
                        System.out.print("Enter quantity: ");
                        int quantity = scanner.nextInt();
                        scanner.nextLine();  // Consume newline
                        hms.addInventory(item, quantity);
                    } else if (inventoryOption == 2) {
                        System.out.print("Enter item name: ");
                        String item = scanner.nextLine();
                        System.out.print("Enter quantity: ");
                        int quantity = scanner.nextInt();
                        scanner.nextLine();  // Consume newline
                        hms.useInventory(item, quantity);
                    }
                    break;

                case 6:
                    System.out.print("Enter staff ID: ");
                    String staffId = scanner.nextLine();
                    System.out.print("Enter staff name: ");
                    String staffName = scanner.nextLine();
                    System.out.print("Enter role: ");
                    String role = scanner.nextLine();
                    System.out.print("Enter department: ");
                    String department = scanner.nextLine();
                    hms.addStaff(staffId, staffName, role, department);
                    break;

                case 7:
                    System.out.println("1. Print Patients");
                    System.out.println("2. Print Appointments");
                    System.out.println("3. Print EHR");
                    System.out.println("4. Print Billings");
                    System.out.println("5. Print Inventory");
                    System.out.println("6. Print Staff");
                    System.out.print("Choose an option: ");
                    int reportOption = scanner.nextInt();
                    scanner.nextLine();  
                    switch (reportOption) {
                        case 1:
                            hms.printPatients();
                            break;
                        case 2:
                            hms.printAppointments();
                            break;
                        case 3:
                            hms.printEHR();
                            break;
                        case 4:
                            hms.printBillings();
                            break;
                        case 5:
                            hms.printInventory();
                            break;
                        case 6:
                            hms.printStaff();
                            break;
                    }
                    break;

                case 8:
                    System.out.println("Exiting...");
                    return;

                default:
                    System.out.println("Invalid option. Try again.");
            }
        }
    }
}
