/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.hospitalmanagementsystem;
/**
 *
 * @author aishu
 */
public class Patient {
    private String patientId;
    private String name;
    private String dateOfBirth;
    private String address;
    private String phoneNumber;

    public Patient(String patientId, String name, String dateOfBirth, String address, String phoneNumber) {
        this.patientId = patientId;
        this.name = name;
        this.dateOfBirth = dateOfBirth;
        this.address = address;
        this.phoneNumber = phoneNumber;
    }

    public String getPatientId() {
        return patientId;
    }

    public String getName() {
        return name;
    }

    public String getDateOfBirth() {
        return dateOfBirth;
    }

    public String getAddress() {
        return address;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    @Override
    public String toString() {
        return "Patient ID: " + patientId + ", Name: " + name + ", DOB: " + dateOfBirth;
    }
}
